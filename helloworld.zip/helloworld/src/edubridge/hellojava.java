package edubridge;

public class hellojava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("****************");
		System.out.println("Welcome to Edubridge");
		System.out.println("My name is Anjana");
		System.out.println("****************");
	}

}
